Thank you so much for showing your appreciation by supporting me as a patron of the exquisite art of software development! 

Your support means a lot to me. Feel free to let me know how I can make my software more useful to you, and don't forget to tell your friends (and that smug elf ranger in your party) about it!

If you haven't done so already, please join my [personal discord](https://discord.gg/N6BNn3x) or [Beyond20's discord](https://discord.gg/ZAasSVS) to talk to me directly.

If you've become a [patron](https://patreon.com/kakaroto) and you linked your Discord account to Patreon, you should get a special role too and access to patron only channels!

Thank you again for your generosity!