Some issues are already known and being worked on.

To check the latest list of known issues or feature suggestions, you can head to the [github issue tracker](https://github.com/kakaroto/Beyond20/issues).

If you find an issue that isn't in the list (check the closed ones for the next milestone too), I'd appreciate you letting me know about it (either by [creating one](https://github.com/kakaroto/Beyond20/issues/new), or by reaching out to me over on [Discord](https://discord.gg/ZAasSVS))!
