# Give rations to this wandering Tiefling 

Thank you for wanting to support me in my adventures!

Beyond20 and the other D&D related software that I've released in the recent years have been sponsored by the generous contributions of my patrons and ko-fi supporters.

In order to help support the continued development of this extension, please pledge to my [Patreon](https://patreon.com/kakaroto) or support the [ko-fi](https://ko-fi.com/gothyl) of the main maintainer of the project.

If you do not want to use Patreon or don't want to pledge a recurring payment or for any other reason, but you still want to support this project financially, then you can do so by buying a ration on [Ko-Fi](https://ko-fi.com/gothyl) using PayPal or a credit card (no signup necessary).

You can read the full patreon/ko-fi page bio for more information on who we are and what we do.

<div>
{% include_relative buttons/patreon.html %} &nbsp;&nbsp; or &nbsp;&nbsp;
{% include_relative buttons/kofi.html %}
</div>


Thank you all for your generous support! I truly appreciate it.
